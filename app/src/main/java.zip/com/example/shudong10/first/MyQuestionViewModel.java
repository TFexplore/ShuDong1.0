package com.example.shudong10.first;

import androidx.lifecycle.ViewModel;

public class MyQuestionViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}