package com.example.shudong10.first;

import androidx.lifecycle.ViewModel;

public class FindViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}